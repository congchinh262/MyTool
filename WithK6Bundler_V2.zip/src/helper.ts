export function randomMinMax(min:number,max:number){
    return Math.random() * (max - min) + min;
}